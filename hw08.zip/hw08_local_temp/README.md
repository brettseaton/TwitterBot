### CIS 1200 Homework 8: Twitterbot

## Homework Instructions

Please follow the instructions provided in the writeup
[here](http://www.cis.upenn.edu/~cis120/current/hw/hw08), as well as the
[Codio documentation](http://www.cis.upenn.edu/~cis120/current/codio/) or the
[IntelliJ instructions](https://www.seas.upenn.edu/~cis120/current/intellij_setup/).